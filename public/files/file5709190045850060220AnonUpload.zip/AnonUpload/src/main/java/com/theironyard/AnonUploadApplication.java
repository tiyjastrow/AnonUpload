package com.theironyard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AnonUploadApplication {

	public static void main(String[] args) {
		SpringApplication.run(AnonUploadApplication.class, args);
	}
}
